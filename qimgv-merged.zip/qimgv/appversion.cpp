#include "appversion.h"

QVersionNumber appVersion(1,1,0);
