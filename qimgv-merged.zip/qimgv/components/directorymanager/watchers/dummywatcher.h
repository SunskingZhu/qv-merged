#pragma once

#include "directorywatcher.h"

class DummyWatcher : public DirectoryWatcher
{
public:
    DummyWatcher();
};
