<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ChangelogWindow</name>
    <message>
        <location filename="../../gui/overlays/changelogwindow.ui" line="154"/>
        <source>Close, never show changelogs</source>
        <translation type="unfinished">Cerrar y no mostrar más</translation>
    </message>
    <message>
        <location filename="../../gui/overlays/changelogwindow.ui" line="170"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../../gui/contextmenu.ui" line="229"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="55"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="59"/>
        <source>Quick copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="63"/>
        <source>Quick move</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="67"/>
        <source>Move to trash</source>
        <translation>Enviar a la papelera</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="72"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="77"/>
        <source>Folder View</source>
        <translation>Vista de Carpetas</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="82"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="85"/>
        <source>Open with...</source>
        <translation>Abrir con...</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="91"/>
        <source>Show in folder</source>
        <translation>Mostrar en carpeta</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="99"/>
        <source>Back</source>
        <translation>Atras</translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="102"/>
        <source>Configure menu</source>
        <translation>Menu de configuracion</translation>
    </message>
</context>
<context>
    <name>CopyOverlay</name>
    <message>
        <location filename="../../gui/overlays/copyoverlay.cpp" line="14"/>
        <location filename="../../gui/overlays/copyoverlay.cpp" line="50"/>
        <source>Copy to...</source>
        <translation>Copiar a...</translation>
    </message>
    <message>
        <location filename="../../gui/overlays/copyoverlay.cpp" line="53"/>
        <source>Move to...</source>
        <translation>Mover a...</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../../core.cpp" line="255"/>
        <source>Updated: </source>
        <translation>Actualizado: </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="261"/>
        <source>Welcome to </source>
        <translation>Bienvenido a </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="261"/>
        <source> version </source>
        <translation> versión </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="268"/>
        <source>Shuffle mode: OFF</source>
        <translation>Modo aleatorio: Apagado</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="271"/>
        <source>Shuffle mode: ON</source>
        <translation>Modo aleatorio: Encendido</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="280"/>
        <source>Slideshow: OFF</source>
        <translation>Diapositivas: Apagado</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="284"/>
        <source>Slideshow: ON</source>
        <translation>Diapositivas: Encendido</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="355"/>
        <source>Delete </source>
        <translation>Eliminar </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="355"/>
        <source> items permanently?</source>
        <translation> ítems permanentemente?</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="357"/>
        <source>Delete item permanently?</source>
        <translation>Eliminar permanentemente?</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="358"/>
        <source>Delete permanently</source>
        <translation>Eliminar permanentemente</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="374"/>
        <source>File removed</source>
        <translation>Archivo eliminado</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="378"/>
        <source>Removed: </source>
        <translation>Eliminado: </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="378"/>
        <location filename="../../core.cpp" line="408"/>
        <source> files</source>
        <translation> archivos</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="389"/>
        <source>Move </source>
        <translation>Mover </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="389"/>
        <source> items to trash?</source>
        <translation> ítems a la papelera?</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="391"/>
        <source>Move item to trash?</source>
        <translation>Mover ítem a la papelera?</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="392"/>
        <source>Move to trash</source>
        <translation>Mover a la papelera</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="404"/>
        <source>Moved to trash</source>
        <translation>Movido a la papelera</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="408"/>
        <source>Moved to trash: </source>
        <translation>Movido a la papelera: </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="463"/>
        <source>File copied</source>
        <translation>Archivo copiado</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="470"/>
        <source>Path copied</source>
        <translation>Ruta copiada</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="644"/>
        <location filename="../../core.cpp" line="918"/>
        <location filename="../../core.cpp" line="939"/>
        <source>File exists</source>
        <translation>Archivo existente</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="644"/>
        <source>Overwrite file?</source>
        <translation>Sobre escribir archivo?</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="812"/>
        <location filename="../../core.cpp" line="880"/>
        <source>Could not create directory </source>
        <translation>No se pudo crear la carpeta </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="916"/>
        <source>File moved.</source>
        <translation>Archivo movido.</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="918"/>
        <location filename="../../core.cpp" line="939"/>
        <source>Destination file exists. Overwrite?</source>
        <translation>El archivo de destino existe. Sobre escribe?</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="937"/>
        <source>File copied.</source>
        <translation>Archivo copiado.</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="984"/>
        <source>Perform action &quot;</source>
        <translation>Ejecutar acción &quot;</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="984"/>
        <source>Changes will be saved immediately.</source>
        <translation>Los cambios serán guardados inmediatamente.</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1002"/>
        <source>Flip horizontal</source>
        <translation>Voltear horizontalmente</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1006"/>
        <source>Flip vertical</source>
        <translation>Voltear verticalmente</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1010"/>
        <source>Rotate</source>
        <translation>Rotar</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1014"/>
        <source>Resize</source>
        <translation>Cambiar tamaño</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1020"/>
        <location filename="../../core.cpp" line="1026"/>
        <source>Crop</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1058"/>
        <source>File saved</source>
        <translation>Archivo grabado</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1061"/>
        <source>Could not save file</source>
        <translation>No se pudo grabar el archivo</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1171"/>
        <source>Could not open image</source>
        <translation>No se pudo abrir la imágen</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1175"/>
        <source>Can only print static images</source>
        <translation>Solo se pueden imprimir imágenes estáticas</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1226"/>
        <source>Could not open path: </source>
        <translation>No se pudo abrir la ruta: </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1260"/>
        <source>Could not load folder: </source>
        <translation>No se pudo cargar la carpeta: </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1413"/>
        <source>End of directory.</source>
        <translation>Fin de la carpeta.</translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1452"/>
        <source>Load failed: </source>
        <translation>Carga fallida: </translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1496"/>
        <source>Error: could not load image.</source>
        <translation>Error: no se pudo cargar la imagen.</translation>
    </message>
</context>
<context>
    <name>CropPanel</name>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="107"/>
        <source>Selection</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="125"/>
        <source>Width</source>
        <translation>Ancho</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="161"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="322"/>
        <source>Aspect Ratio</source>
        <translation>Relacion de aspecto</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="336"/>
        <source>Free</source>
        <translation>Libre</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="341"/>
        <source>Custom</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="346"/>
        <source>Current Image</source>
        <translation>Imagen actual</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="351"/>
        <source>This Screen</source>
        <translation>Esta pantalla</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="356"/>
        <source>1:1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="361"/>
        <source>4:3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="366"/>
        <source>16:9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="371"/>
        <source>16:10</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="499"/>
        <source>Crop</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="512"/>
        <source>Crop &amp;&amp; Save</source>
        <translation>Recortar y grabar</translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="527"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>FVOptionsPopup</name>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.ui" line="53"/>
        <source>View options</source>
        <translation>Opciones de visualización</translation>
    </message>
</context>
<context>
    <name>FileReplaceDialog</name>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="20"/>
        <source>title</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="33"/>
        <source>Source:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="40"/>
        <source>src</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="50"/>
        <source>&gt;&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="63"/>
        <source>Destination:</source>
        <translation>Destino:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="70"/>
        <source>dst</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="111"/>
        <source>Apply to all</source>
        <translation>Aplicar a todo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="118"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="125"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="132"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>FolderView</name>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="145"/>
        <source>[path]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="195"/>
        <source>FolderViewSlider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="242"/>
        <source>CheckableButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="274"/>
        <source>PanelComboBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="281"/>
        <source>A - Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="286"/>
        <source>Z - A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="291"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="296"/>
        <source>Size (desc)</source>
        <translation>Tamaño (desc)</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="301"/>
        <source>Oldest</source>
        <translation>Más viejo</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="306"/>
        <source>Newest</source>
        <translation>Más nuevo</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="348"/>
        <location filename="../../gui/folderview/folderview.ui" line="373"/>
        <source>PanelButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="414"/>
        <source>PanelButtonRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="476"/>
        <source>PlacesPanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="532"/>
        <source>BOOKMARKS</source>
        <translation type="unfinished">Marcadores</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="551"/>
        <location filename="../../gui/folderview/folderview.ui" line="638"/>
        <location filename="../../gui/folderview/folderview.ui" line="657"/>
        <source>PlacesPanelButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="611"/>
        <source>FILESYSTEM</source>
        <translation>Mi equipo</translation>
    </message>
</context>
<context>
    <name>ImageInfoOverlay</name>
    <message>
        <location filename="../../gui/overlays/imageinfooverlay.ui" line="65"/>
        <source>OverlayHeaderWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/imageinfooverlay.ui" line="99"/>
        <source>EXIF Tags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../gui/customwidgets/keysequenceedit.cpp" line="4"/>
        <source>[Enter sequence]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MW</name>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="565"/>
        <source>Save File as...</source>
        <translation>Guardar como...</translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="800"/>
        <source>Folder view</source>
        <translation>Vista de carpetas</translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="801"/>
        <location filename="../../gui/mainwindow.cpp" line="802"/>
        <location filename="../../gui/mainwindow.cpp" line="805"/>
        <location filename="../../gui/mainwindow.cpp" line="806"/>
        <source>No file opened.</source>
        <translation>No se abrió el archivo.</translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="867"/>
        <source>Fit Window</source>
        <translation>Encajar en la ventana</translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="871"/>
        <source>Fit Width</source>
        <translation>Encajar ancho</translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="875"/>
        <source>Fit 1:1</source>
        <translation>Proporción 1:1</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="20"/>
        <source>Print image</source>
        <translation>Imprimir imagen</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="126"/>
        <source>Preview</source>
        <translation>Previsualización</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="179"/>
        <source>Printer:</source>
        <translation>Impresora:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="189"/>
        <source>&lt;No printers found&gt;</source>
        <translation>&lt;Sin impresoras&gt;</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="271"/>
        <source>Page orientation:</source>
        <translation>Orientación de página:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="297"/>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="307"/>
        <source>Landscape</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="348"/>
        <source>Color mode:</source>
        <translation>Modo de color:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="374"/>
        <source>Grayscale</source>
        <translation>Escala de grises</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="384"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="409"/>
        <source>Fit to page</source>
        <translation>Encajar en la página</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="434"/>
        <source>Export PDF</source>
        <translation>Exportar a PDF</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="454"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="464"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.cpp" line="70"/>
        <source>Choose pdf location</source>
        <translation>Seleccionar ubicacion del PDF</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.cpp" line="13"/>
        <source>Simple</source>
        <translation>Sencillo</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.cpp" line="14"/>
        <source>Extended</source>
        <translation>Extendido</translation>
    </message>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.cpp" line="15"/>
        <source>Extended + Folders</source>
        <translation>Extendido + Carpetas</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="218"/>
        <source>Make</source>
        <translation>Capturar</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="222"/>
        <source>Model</source>
        <translation>Modelo</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="226"/>
        <source>Date/Time</source>
        <translation>Fecha/Hora</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="233"/>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="236"/>
        <source>ExposureTime</source>
        <translation>Tiempo de exposición</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="233"/>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="236"/>
        <source> sec</source>
        <translation> seg</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="244"/>
        <source>F Number</source>
        <translation>Número F</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="249"/>
        <source>ISO Speed ratings</source>
        <translation>Rangos de velocidad ISO</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="253"/>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="259"/>
        <source>Focal Length</source>
        <translation>Longitud focal</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="259"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="268"/>
        <source>UserComment</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="43"/>
        <source>Operation completed succesfully.</source>
        <translation>Operación completada satisfactoriamente.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="45"/>
        <source>Destination file exists.</source>
        <translation>El archivo de destino existe.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="47"/>
        <source>Destination directory exists.</source>
        <translation>La carpeta de destino ya existe.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="49"/>
        <source>Source file is not writable.</source>
        <translation>El archivo de origen es de sólo lectura.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="51"/>
        <source>Destination is not writable.</source>
        <translation>El archivo de destino es de solo lectura.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="53"/>
        <source>Source file does not exist.</source>
        <translation>El archivo de origen no existe.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="55"/>
        <source>Destination does not exist.</source>
        <translation>La carpeta de destino no existe.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="57"/>
        <source>Directory is not empty.</source>
        <translation>La carpeta no esta vacía.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="59"/>
        <source>Nothing to do.</source>
        <translation>Nada por hacer.</translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="61"/>
        <source>Other error.</source>
        <translation>Otro error.</translation>
    </message>
</context>
<context>
    <name>RenameOverlay</name>
    <message>
        <location filename="../../gui/overlays/renameoverlay.ui" line="171"/>
        <location filename="../../gui/overlays/renameoverlay.ui" line="260"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../../gui/overlays/renameoverlay.ui" line="273"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>ResizeDialog</name>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="32"/>
        <source>Resize</source>
        <translation>Cambiar tamaño</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="63"/>
        <source>By Percent:</source>
        <translation>Por porcentaje:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="79"/>
        <source>By Absolute Size:</source>
        <translation>Por tamaño absoluto:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="98"/>
        <source>Percent:</source>
        <translation>Porcentaje:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="119"/>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="205"/>
        <source>Height:</source>
        <translation>Altura:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="275"/>
        <source>Keep aspect ratio</source>
        <translation>Mantener relacion de aspecto</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="304"/>
        <source>Filter:</source>
        <translation>Filtro:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="330"/>
        <source>Nearest</source>
        <translation type="unfinished">Más cercano</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="335"/>
        <source>Bilinear</source>
        <translation>Bilineal</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="340"/>
        <source>Bicubic</source>
        <translation>Bicubico</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="345"/>
        <source>Lanczos3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="358"/>
        <source>Common sizes:</source>
        <translation>Tamaños comunes:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="392"/>
        <source>Select:</source>
        <translation>Seleccionar:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="397"/>
        <source>1366 x 768</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="402"/>
        <source>1440 x 900</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="407"/>
        <source>1440 x 1050</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="412"/>
        <source>1600 x 1200</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="417"/>
        <source>1920 x 1080 (FullHD)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="422"/>
        <source>1920 x 1200 (FullHD)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="427"/>
        <source>2560 x 1080</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="432"/>
        <source>2560 x 1440</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="437"/>
        <source>2560 x 1600</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="442"/>
        <source>3840 x 1600 (UW 4K)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="447"/>
        <source>3840 x 2160 (UHD-1)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="470"/>
        <source>Fit to desktop</source>
        <translation>Encajar al escritorio</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="489"/>
        <source>Fill desktop (expanding)</source>
        <translation>Rellenar escritorio (expandiendo)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="508"/>
        <source>Reset</source>
        <translation>Resetear</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="575"/>
        <source>OK</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="594"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.cpp" line="19"/>
        <source>Reset:</source>
        <translation>Resetear:</translation>
    </message>
</context>
<context>
    <name>SSideBar</name>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="9"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="10"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="11"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="12"/>
        <source>Controls</source>
        <translation>Controles</translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="13"/>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="14"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="15"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
</context>
<context>
    <name>SaveConfirmOverlay</name>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="81"/>
        <source>Unsaved edits</source>
        <translation>Cambios sin guardar</translation>
    </message>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="127"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="140"/>
        <source>Save as</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="169"/>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>ScriptEditorDialog</name>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="48"/>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="84"/>
        <source>NOTE: make sure your .sh script has execute flag.</source>
        <translation>NOTA: Asegúrese que el script sea ejecutable.</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="91"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="148"/>
        <source>Wait to finish</source>
        <translation>Esperar hasta finalizar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="218"/>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="225"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="10"/>
        <source>New application/script</source>
        <translation>Nuevo script/aplicación</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="11"/>
        <source>Keywords:</source>
        <translation>Palabras clave:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="22"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="46"/>
        <source>Enter script name</source>
        <translation>Nombre del script</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="58"/>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="65"/>
        <source>A script with this same name exists</source>
        <translation>Existe un script de igual nombre</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="78"/>
        <source>Select an executable/script</source>
        <translation>Seleccionar script/ejecutable</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="80"/>
        <source>Select a script file</source>
        <translation>Seleccionar archivo del script</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="47"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="53"/>
        <source>SettingsDialog</source>
        <translation>Ventana de configuracion</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="339"/>
        <source>General</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="415"/>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="435"/>
        <source>Requires application restart</source>
        <translation>Requiere reiniciar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="473"/>
        <source>Open in fullscreen</source>
        <translation>Abrir en pantalla completa</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="480"/>
        <source>Start in folder view by default</source>
        <translation>Abrir por defecto en vista de carpetas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="551"/>
        <source>User interface</source>
        <translation>Interfaz de usuario</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="606"/>
        <source>Image info in window title</source>
        <translation>Informacion de la imagen en barra de titulos</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="626"/>
        <source>Auto-hide cursor</source>
        <translation>Ocultar cursor automaticamente</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="633"/>
        <source>Turn this off if you are using a touchpad with libinput driver.</source>
        <translation>Desactivar si esta utilizando un panel táctil con el controlador de libimput.</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="636"/>
        <source>Enable smooth scrolling</source>
        <translation>Usar desplazamiento suave</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="643"/>
        <source>Fullscreen info bar</source>
        <translation>Barra de información en pantalla completa</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="656"/>
        <source>Status bar</source>
        <translation>Barra de estado</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="689"/>
        <source>Zoom indicator:</source>
        <translation>Indicador de zoom:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="699"/>
        <source>On</source>
        <translation>Encendido</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="706"/>
        <source>Off</source>
        <translation>Apagado</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="713"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="753"/>
        <source>Automatic window resize</source>
        <translation>Redimensionar la ventana automáticamente</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="763"/>
        <source>Match displayed content</source>
        <translation>Ajustar al contenido mostrado</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="799"/>
        <source>Screen area limit for auto resize:</source>
        <translation>límite de pantalla para auto dimensionado:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="864"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2240"/>
        <source>xx</source>
        <translation>xx</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="962"/>
        <source>Thumbnail panel</source>
        <translation>Panel de miniaturas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1018"/>
        <source>Crop previews</source>
        <translation>Recortar miniaturas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1031"/>
        <source>Pinned</source>
        <translation>Fijo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1050"/>
        <source>Disable in windowed mode</source>
        <translation>Desactivar en modo ventana</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1057"/>
        <source>Center selected image</source>
        <translation>Centrar la imagen seleccionada</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1109"/>
        <source>Extended</source>
        <translation>Extendido</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1119"/>
        <source>Previews only</source>
        <translation>Solo vistas previas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1126"/>
        <source>Display style:</source>
        <translation>Estilo de visualización:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1139"/>
        <source>Show filename and resolution</source>
        <translation type="unfinished">Mostrar nombre y resolución</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1159"/>
        <source>Simple</source>
        <translation>Sencillo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1183"/>
        <source>Preview size:</source>
        <translation>Tamaño de previsualización:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1258"/>
        <source>Position:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1266"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2064"/>
        <source>Top</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1271"/>
        <source>Bottom</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1276"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1281"/>
        <source>Right</source>
        <translation>Derecha</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1374"/>
        <source>Folder navigation</source>
        <translation>Navegador de carpetas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1400"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1410"/>
        <source>Loop folder</source>
        <translation type="unfinished">Carpetas en bucle</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1417"/>
        <source>Go to the next folder</source>
        <translation>Ir a la siguiente carpeta</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1424"/>
        <source>After reaching the end:</source>
        <translation>Despues de alcanzar el final:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1476"/>
        <source>Default sorting mode:</source>
        <translation>Ordenamiento por defecto:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1493"/>
        <source>A - Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1498"/>
        <source>Z - A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1503"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1508"/>
        <source>Size (desc)</source>
        <translation>Tamaño (descendiente)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1513"/>
        <source>Oldest</source>
        <translation type="unfinished">Más viejo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1518"/>
        <source>Newest</source>
        <translation type="unfinished">Más nuevo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1541"/>
        <source>Apply sorting to folders</source>
        <translation>Aplicar ordenamiento a carpetar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1609"/>
        <source>Video playback</source>
        <translation>Reproducción de vídeo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1651"/>
        <source>Play sounds</source>
        <translation>Reproducir sonidos</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1720"/>
        <source>Slideshow</source>
        <translation>Diapositivas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1740"/>
        <source>Switch interval:</source>
        <translation>Intervalo entre diapositivas:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1771"/>
        <source>ms</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1803"/>
        <source>Loop slideshow</source>
        <translation>Diapositivas en bucle</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1900"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1956"/>
        <source>Display options</source>
        <translation>Opciones de visualización</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1980"/>
        <source>Image fit:</source>
        <translation>Encajar imagen:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1987"/>
        <source>Fit in window</source>
        <translation>Encajar en la ventana</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1997"/>
        <source>Stretch to width</source>
        <translation>Encajar al ancho</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2004"/>
        <source>1:1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2026"/>
        <source>Keep fit mode when switching images</source>
        <translation>Mantener modo de encaje al cambiar de imagen</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2057"/>
        <source>Focus in 1:1 mode:</source>
        <translation>Enfoque en modo 1:1:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2071"/>
        <source>Center</source>
        <translation>Centrar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2078"/>
        <source>At cursor</source>
        <translation>Sobre el cursor</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2103"/>
        <source>Part of image that&apos;s focused after switching to 1:1</source>
        <translation>Parte de la imagen enfocada después de cambiar a 1:1</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2126"/>
        <source>Grid background on images with transparency</source>
        <translation>Fondo de cuadrícula en imágenes con transparencia</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2163"/>
        <source>Expand images, up to:</source>
        <translation>Ampliar imágenes, hasta:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2271"/>
        <source>Images smaller than window will be zoomed in</source>
        <translation>Las imágenes más pequeñas que la ventana se ampliarán</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2323"/>
        <source>Zoom options</source>
        <translation>Opciones de zoom</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2330"/>
        <source>Unlock minimum zoom</source>
        <translation>Desbloquear zoom mínimo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2340"/>
        <source>Always allow zooming below 100%</source>
        <translation>Permitir siempre hacer zoom por debajo del 100%</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2365"/>
        <source>Zoom step:</source>
        <translation>Paso de zoom:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2433"/>
        <source>[step]</source>
        <translation>[salto]</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2462"/>
        <source>Use fixed zoom levels:</source>
        <translation>Usar niveles de zoom fijos:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2506"/>
        <source>Load defaults</source>
        <translation>Cargar opciones por defecto</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2574"/>
        <source>Scaling quality</source>
        <translation>Calidad de escala</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2601"/>
        <source>Scaling filter:</source>
        <translation>Filtro de escala:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2633"/>
        <source>Nearest neighbor</source>
        <translation>Más cercano</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2638"/>
        <source>Bilinear</source>
        <translation>Bilinear</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2680"/>
        <source>When unchecked, nearest neighbor algorithm will be used for upscaling.</source>
        <translation>Cuando no está marcado, se utilizará el algoritmo del vecino más cercano para la ampliación.</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2683"/>
        <source>Smooth upscaling</source>
        <translation>Suavizar ampliacion</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2702"/>
        <source>Smooth animated images</source>
        <translation>Suavizar imágenes animadas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2781"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2840"/>
        <source>Load preset:</source>
        <translation>Cargar preajuste:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2853"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2857"/>
        <source>Black</source>
        <translation>Negro</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2862"/>
        <source>Dark</source>
        <translation>Oscuro</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2867"/>
        <source>Dark Blue</source>
        <translation>Azul oscuro</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2872"/>
        <source>Light</source>
        <translation>Ligero</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2896"/>
        <source>Use system colors</source>
        <translation>Usar colores del sistema</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2906"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;modify&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;modificar&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3132"/>
        <source>Accent</source>
        <translation>Primer plano</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3139"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3146"/>
        <source>Background (fullscreen mode)</source>
        <translation>Fondo (modo de pantalla completa)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3184"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3191"/>
        <source>Icons</source>
        <translation>Iconos</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3291"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="62"/>
        <source>Overlay background</source>
        <translation>Fondo superpuesto</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3329"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="60"/>
        <source>Widget background</source>
        <translation>Fondo de widgets</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3336"/>
        <source>Folder view top panel</source>
        <translation>Panel superior de vista de carpetas</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3343"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="61"/>
        <source>Widget border</source>
        <translation>Borde del widget</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3412"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="63"/>
        <source>Overlay text</source>
        <translation>Texto superpuesto</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3450"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="64"/>
        <source>Scrollbars</source>
        <translation>Barras de desplazamiento</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3457"/>
        <source>Folder view background</source>
        <translation>Fondo de vista de carpeta</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3528"/>
        <source>Other window tweaks</source>
        <translation>Otros ajustes de ventana</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3543"/>
        <source>Window opacity:</source>
        <translation>Opacidad de la ventana:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3596"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3621"/>
        <source>Background blur (KDE)</source>
        <translation>Fondo borroso (KDE)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3673"/>
        <source>Controls</source>
        <translation>Controles</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3734"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4073"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3741"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4080"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3754"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4087"/>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3783"/>
        <source>Reset to defaults</source>
        <translation type="unfinished">Restablecer valores predeterminados</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3817"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3822"/>
        <source>Shortcut</source>
        <translation>Atajo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3874"/>
        <source>Mouse &amp; touchpad</source>
        <translation>Ratón y panel táctil</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3895"/>
        <source>Scroll image with:</source>
        <translation type="unfinished">Desplazar la imagen con:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3903"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3908"/>
        <source>Touchpad</source>
        <translation>Panel táctil</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3913"/>
        <source>Touchpad &amp; Mouse Wheel</source>
        <translation>Panel táctil y rueda del ratón</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3939"/>
        <source>Note: you can also zoom by holding RMB and moving the mouse</source>
        <translation>Nota: también puedes hacer zoom manteniendo presionado el botón derecho y moviendo el ratón</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3953"/>
        <source>Trackpad detection</source>
        <translation>Detección de panel táctil</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3963"/>
        <source>Disable if you have issues with mouse scrolling</source>
        <translation>Desactívelo si tiene problemas con el desplazamiento del ratón</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3995"/>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4051"/>
        <source>Note: these will appear in &quot;Open with&quot; menu.</source>
        <translation>Nota: aparecerán en el menú &quot;Abrir con&quot;.</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4061"/>
        <source>Also, you can assign shortcuts to scripts (in &quot;Controls&quot; section).</source>
        <translation>Además, puede asignar accesos directos a los scripts (en la sección &quot;Controles&quot;).</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4170"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4227"/>
        <source>Preload the next/previous image. Results in a much faster image switching (at the expense of wasting more RAM).</source>
        <translation>Precarga la imagen siguiente/anterior. Provoca un cambio de imagen mucho más rápido (a expensas de desperdiciar más RAM).</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4230"/>
        <source>Use preloader (recommended)</source>
        <translation>Usar precargador (recomendado)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4240"/>
        <source>Load adjacent images in background</source>
        <translation>Cargar imágenes adyacentes en segundo plano</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4268"/>
        <source>Thumbnailer thread count:</source>
        <translation>Número de hilos del generador de miniaturas:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4306"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4337"/>
        <source>Use thumbnail cache (recommended)</source>
        <translation>Usar caché de miniaturas (recomendado)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4344"/>
        <source>Unload off-screen thumbnails</source>
        <translation>Descargar miniaturas fuera de pantalla</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4354"/>
        <source>Dynamically unload items to save memory</source>
        <translation>Descargue elementos dinámicamente para ahorrar memoria</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4368"/>
        <source>Show save overlay when editing images</source>
        <translation>Mostrar superposición de guardado al editar imágenes</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4383"/>
        <source>JPEG save quality:</source>
        <translation>Calidad de guardado JPEG:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4427"/>
        <source>q</source>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4456"/>
        <source>Confirm moving to trash</source>
        <translation>Confirmar mover a la papelera</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4468"/>
        <source>Confirm file delete (!)</source>
        <translation>Confirmar eliminación del archivo (!)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4482"/>
        <source>JXL animation support (experimental)</source>
        <translation>Soporte de animación JXL (experimental)</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4510"/>
        <source>Memory allocation limit per image, MB:</source>
        <translation>Límite de asignación de memoria por imagen, MB:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4571"/>
        <source>Mpv binary:</source>
        <translation>Ruta del ejecutable mpv:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4612"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4706"/>
        <source>About qimgv</source>
        <translation>Acerca de qimgv</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4757"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;This is a fast and easy to use image viewer&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Features video support via libmpv&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic;&quot;&gt;Github page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;https://github.com/easymodo/qimgv&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic;&quot;&gt;Main developer:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic;&quot;&gt; easymodo (easymodofrf@gmail.com)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv/graphs/contributors&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;Contributors&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;OpenCV enabled builds use &lt;/span&gt;&lt;a href=&quot;https://github.com/dbzhang800/QtOpenCV&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;QtOpenCV&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt; by dbzhang800&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;qimgv is licensed under &lt;/span&gt;&lt;a href=&quot;https://www.gnu.org/licenses/gpl-3.0.en.html&quot;&gt;&lt;span style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;GNU GPL Version 3&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Report any issues / request features &lt;/span&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;here&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;&lt;html&gt;&lt;head&gt; &lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt; &lt;meta charset=&quot;utf-8&quot; /&gt; &lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } hr { height: 1px; border-width: 0; } li.unchecked::marker { content: &quot;\2610&quot;; } li.checked::marker { content: &quot;\2612&quot;; } &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Este es un visor de imágenes sencillo y rápido&lt;/span&gt; &lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Incluye soporte de vídeo a través de libmpv.&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic;&quot;&gt;Proyecto en GitHub:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;https://github.com/easymodo/qimgv&lt;/span&gt;&lt;/a&gt; &lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic;&quot;&gt;Desarrollado por:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic;&quot;&gt; easymodo (easymodofrf@gmail.com)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;a href=&quot;https://github.com/easymodo/qimgv/graphs/contributors&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;Contributors&lt;/span&gt;&lt;/a&gt; &lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt; &lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Compilaciones con OpenCV habilitado a trav&amp;eacute;s de &lt;/span&gt;&lt;a href=&quot;https://github.com/dbzhang800/QtOpenCV&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;QtOpenCV&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt; by dbzhang800&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt; &lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;qimgv est&amp;aacute; licenciado bajo &lt;/span&gt;&lt;a href=&quot;https://www.gnu.org/licenses/gpl-3.0.en.html&quot;&gt;&lt;span style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;GNU GPL Versi&amp;oacute;n 3&lt;/span&gt;&lt;/a&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt; &lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Informar cualquier problema o solicitar funciones &lt;/span&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;aqu&amp;iacute;&lt;/span&gt;&lt;/a&gt; &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4850"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4857"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4864"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="9"/>
        <source>Preferences — </source>
        <translation>Preferencias — </translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="54"/>
        <source>Accent color</source>
        <translation>Color de primer plano</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="55"/>
        <source>Windowed mode background</source>
        <translation>Fondo en modo ventana</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="56"/>
        <source>Fullscreen mode background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="57"/>
        <source>FolderView background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="58"/>
        <source>FolderView top panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="59"/>
        <source>Text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="569"/>
        <source>Edit shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="620"/>
        <source>Navigate to mpv binary</source>
        <translation>Ubicar el ejecutable mpv</translation>
    </message>
</context>
<context>
    <name>ShortcutCreatorDialog</name>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="14"/>
        <source>New shortcut</source>
        <translation>Nuevo atajo</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="34"/>
        <source>Action:</source>
        <translation>Acción:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="73"/>
        <source>Script:</source>
        <translation>Script:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="117"/>
        <source>Shortcut:</source>
        <translation>Atajo de teclado:</translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="124"/>
        <source>[Enter shortcut]</source>
        <translation>[Introducir atajo]</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../main.cpp" line="133"/>
        <source>File or directory path.</source>
        <translation>Ruta del archivo o carpeta.</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="136"/>
        <source>Generate all thumbnails for directory.</source>
        <translation>Generar todas las miniaturas de la carpeta.</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="137"/>
        <source>directory-path</source>
        <translation>ruta-de-la-carpeta</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="139"/>
        <source>Thumbnail size. Current size is used if not specified.</source>
        <translation>Tamaño de las miniaturas. Si no se especifica se utilizara el tamaño original.</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="140"/>
        <source>thumbnail-size</source>
        <translation>tamaño-de-miniatura</translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="142"/>
        <source>Show build options.</source>
        <translation>Opciones de visualización.</translation>
    </message>
</context>
</TS>
