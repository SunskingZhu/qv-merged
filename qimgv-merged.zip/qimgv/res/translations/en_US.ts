<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ChangelogWindow</name>
    <message>
        <location filename="../../gui/overlays/changelogwindow.ui" line="154"/>
        <source>Close, never show changelogs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/changelogwindow.ui" line="170"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../../gui/contextmenu.ui" line="229"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="55"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="59"/>
        <source>Quick copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="63"/>
        <source>Quick move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="67"/>
        <source>Move to trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="72"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="77"/>
        <source>Folder View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="82"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="85"/>
        <source>Open with...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="91"/>
        <source>Show in folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="99"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/contextmenu.cpp" line="102"/>
        <source>Configure menu</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CopyOverlay</name>
    <message>
        <location filename="../../gui/overlays/copyoverlay.cpp" line="14"/>
        <location filename="../../gui/overlays/copyoverlay.cpp" line="50"/>
        <source>Copy to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/copyoverlay.cpp" line="53"/>
        <source>Move to...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../../core.cpp" line="255"/>
        <source>Updated: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="261"/>
        <source>Welcome to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="261"/>
        <source> version </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="268"/>
        <source>Shuffle mode: OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="271"/>
        <source>Shuffle mode: ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="280"/>
        <source>Slideshow: OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="284"/>
        <source>Slideshow: ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="355"/>
        <source>Delete </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="355"/>
        <source> items permanently?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="357"/>
        <source>Delete item permanently?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="358"/>
        <source>Delete permanently</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="374"/>
        <source>File removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="378"/>
        <source>Removed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="378"/>
        <location filename="../../core.cpp" line="408"/>
        <source> files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="389"/>
        <source>Move </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="389"/>
        <source> items to trash?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="391"/>
        <source>Move item to trash?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="392"/>
        <source>Move to trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="404"/>
        <source>Moved to trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="408"/>
        <source>Moved to trash: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="463"/>
        <source>File copied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="470"/>
        <source>Path copied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="644"/>
        <location filename="../../core.cpp" line="918"/>
        <location filename="../../core.cpp" line="939"/>
        <source>File exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="644"/>
        <source>Overwrite file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="812"/>
        <location filename="../../core.cpp" line="880"/>
        <source>Could not create directory </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="916"/>
        <source>File moved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="918"/>
        <location filename="../../core.cpp" line="939"/>
        <source>Destination file exists. Overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="937"/>
        <source>File copied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="984"/>
        <source>Perform action &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="984"/>
        <source>Changes will be saved immediately.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1002"/>
        <source>Flip horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1006"/>
        <source>Flip vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1010"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1014"/>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1020"/>
        <location filename="../../core.cpp" line="1026"/>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1058"/>
        <source>File saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1061"/>
        <source>Could not save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1171"/>
        <source>Could not open image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1175"/>
        <source>Can only print static images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1226"/>
        <source>Could not open path: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1260"/>
        <source>Could not load folder: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1413"/>
        <source>End of directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1452"/>
        <source>Load failed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../core.cpp" line="1496"/>
        <source>Error: could not load image.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CropPanel</name>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="107"/>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="125"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="161"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="322"/>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="336"/>
        <source>Free</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="341"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="346"/>
        <source>Current Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="351"/>
        <source>This Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="356"/>
        <source>1:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="361"/>
        <source>4:3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="366"/>
        <source>16:9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="371"/>
        <source>16:10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="499"/>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="512"/>
        <source>Crop &amp;&amp; Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/panels/croppanel/croppanel.ui" line="527"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FVOptionsPopup</name>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.ui" line="53"/>
        <source>View options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileReplaceDialog</name>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="20"/>
        <source>title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="33"/>
        <source>Source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="40"/>
        <source>src</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="50"/>
        <source>&gt;&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="63"/>
        <source>Destination:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="70"/>
        <source>dst</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="111"/>
        <source>Apply to all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="118"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="125"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/filereplacedialog.ui" line="132"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FolderView</name>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="145"/>
        <source>[path]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="195"/>
        <source>FolderViewSlider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="242"/>
        <source>CheckableButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="274"/>
        <source>PanelComboBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="281"/>
        <source>A - Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="286"/>
        <source>Z - A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="291"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="296"/>
        <source>Size (desc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="301"/>
        <source>Oldest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="306"/>
        <source>Newest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="348"/>
        <location filename="../../gui/folderview/folderview.ui" line="373"/>
        <source>PanelButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="414"/>
        <source>PanelButtonRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="476"/>
        <source>PlacesPanel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="532"/>
        <source>BOOKMARKS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="551"/>
        <location filename="../../gui/folderview/folderview.ui" line="638"/>
        <location filename="../../gui/folderview/folderview.ui" line="657"/>
        <source>PlacesPanelButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/folderview.ui" line="611"/>
        <source>FILESYSTEM</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageInfoOverlay</name>
    <message>
        <location filename="../../gui/overlays/imageinfooverlay.ui" line="65"/>
        <source>OverlayHeaderWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/imageinfooverlay.ui" line="99"/>
        <source>EXIF Tags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../gui/customwidgets/keysequenceedit.cpp" line="4"/>
        <source>[Enter sequence]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MW</name>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="565"/>
        <source>Save File as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="800"/>
        <source>Folder view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="801"/>
        <location filename="../../gui/mainwindow.cpp" line="802"/>
        <location filename="../../gui/mainwindow.cpp" line="805"/>
        <location filename="../../gui/mainwindow.cpp" line="806"/>
        <source>No file opened.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="867"/>
        <source>Fit Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="871"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/mainwindow.cpp" line="875"/>
        <source>Fit 1:1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="20"/>
        <source>Print image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="126"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="179"/>
        <source>Printer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="189"/>
        <source>&lt;No printers found&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="271"/>
        <source>Page orientation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="297"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="307"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="348"/>
        <source>Color mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="374"/>
        <source>Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="384"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="409"/>
        <source>Fit to page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="434"/>
        <source>Export PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="454"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.ui" line="464"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/printdialog.cpp" line="70"/>
        <source>Choose pdf location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.cpp" line="13"/>
        <source>Simple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.cpp" line="14"/>
        <source>Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/folderview/fvoptionspopup.cpp" line="15"/>
        <source>Extended + Folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="218"/>
        <source>Make</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="222"/>
        <source>Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="226"/>
        <source>Date/Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="233"/>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="236"/>
        <source>ExposureTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="233"/>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="236"/>
        <source> sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="244"/>
        <source>F Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="249"/>
        <source>ISO Speed ratings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="253"/>
        <source>Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="259"/>
        <source>Focal Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="259"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../sourcecontainers/documentinfo.cpp" line="268"/>
        <source>UserComment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="43"/>
        <source>Operation completed succesfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="45"/>
        <source>Destination file exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="47"/>
        <source>Destination directory exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="49"/>
        <source>Source file is not writable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="51"/>
        <source>Destination is not writable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="53"/>
        <source>Source file does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="55"/>
        <source>Destination does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="57"/>
        <source>Directory is not empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="59"/>
        <source>Nothing to do.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/fileoperations.cpp" line="61"/>
        <source>Other error.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RenameOverlay</name>
    <message>
        <location filename="../../gui/overlays/renameoverlay.ui" line="171"/>
        <location filename="../../gui/overlays/renameoverlay.ui" line="260"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/renameoverlay.ui" line="273"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResizeDialog</name>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="32"/>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="63"/>
        <source>By Percent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="79"/>
        <source>By Absolute Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="98"/>
        <source>Percent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="119"/>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="205"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="275"/>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="304"/>
        <source>Filter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="330"/>
        <source>Nearest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="335"/>
        <source>Bilinear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="340"/>
        <source>Bicubic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="345"/>
        <source>Lanczos3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="358"/>
        <source>Common sizes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="392"/>
        <source>Select:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="397"/>
        <source>1366 x 768</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="402"/>
        <source>1440 x 900</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="407"/>
        <source>1440 x 1050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="412"/>
        <source>1600 x 1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="417"/>
        <source>1920 x 1080 (FullHD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="422"/>
        <source>1920 x 1200 (FullHD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="427"/>
        <source>2560 x 1080</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="432"/>
        <source>2560 x 1440</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="437"/>
        <source>2560 x 1600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="442"/>
        <source>3840 x 1600 (UW 4K)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="447"/>
        <source>3840 x 2160 (UHD-1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="470"/>
        <source>Fit to desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="489"/>
        <source>Fill desktop (expanding)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="508"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="575"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.ui" line="594"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/resizedialog.cpp" line="19"/>
        <source>Reset:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SSideBar</name>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="9"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="10"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="11"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="12"/>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="13"/>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="14"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/customwidgets/ssidebar.cpp" line="15"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveConfirmOverlay</name>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="81"/>
        <source>Unsaved edits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="127"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="140"/>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/overlays/saveconfirmoverlay.ui" line="169"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScriptEditorDialog</name>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="48"/>
        <source>Command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="84"/>
        <source>NOTE: make sure your .sh script has execute flag.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="91"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="148"/>
        <source>Wait to finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="218"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.ui" line="225"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="10"/>
        <source>New application/script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="11"/>
        <source>Keywords:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="22"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="46"/>
        <source>Enter script name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="58"/>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="65"/>
        <source>A script with this same name exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="78"/>
        <source>Select an executable/script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/scripteditordialog.cpp" line="80"/>
        <source>Select a script file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="47"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="53"/>
        <source>SettingsDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="339"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="415"/>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="435"/>
        <source>Requires application restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="473"/>
        <source>Open in fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="480"/>
        <source>Start in folder view by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="551"/>
        <source>User interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="606"/>
        <source>Image info in window title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="626"/>
        <source>Auto-hide cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="633"/>
        <source>Turn this off if you are using a touchpad with libinput driver.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="636"/>
        <source>Enable smooth scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="643"/>
        <source>Fullscreen info bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="656"/>
        <source>Status bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="689"/>
        <source>Zoom indicator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="699"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="706"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="713"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="753"/>
        <source>Automatic window resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="763"/>
        <source>Match displayed content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="799"/>
        <source>Screen area limit for auto resize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="864"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2240"/>
        <source>xx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="962"/>
        <source>Thumbnail panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1018"/>
        <source>Crop previews</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1031"/>
        <source>Pinned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1050"/>
        <source>Disable in windowed mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1057"/>
        <source>Center selected image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1109"/>
        <source>Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1119"/>
        <source>Previews only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1126"/>
        <source>Display style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1139"/>
        <source>Show filename and resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1159"/>
        <source>Simple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1183"/>
        <source>Preview size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1258"/>
        <source>Position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1266"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2064"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1271"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1276"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1281"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1374"/>
        <source>Folder navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1400"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1410"/>
        <source>Loop folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1417"/>
        <source>Go to the next folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1424"/>
        <source>After reaching the end:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1476"/>
        <source>Default sorting mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1493"/>
        <source>A - Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1498"/>
        <source>Z - A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1503"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1508"/>
        <source>Size (desc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1513"/>
        <source>Oldest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1518"/>
        <source>Newest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1541"/>
        <source>Apply sorting to folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1609"/>
        <source>Video playback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1651"/>
        <source>Play sounds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1720"/>
        <source>Slideshow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1740"/>
        <source>Switch interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1771"/>
        <source>ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1803"/>
        <source>Loop slideshow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1900"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1956"/>
        <source>Display options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1980"/>
        <source>Image fit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1987"/>
        <source>Fit in window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="1997"/>
        <source>Stretch to width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2004"/>
        <source>1:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2026"/>
        <source>Keep fit mode when switching images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2057"/>
        <source>Focus in 1:1 mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2071"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2078"/>
        <source>At cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2103"/>
        <source>Part of image that&apos;s focused after switching to 1:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2126"/>
        <source>Grid background on images with transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2163"/>
        <source>Expand images, up to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2271"/>
        <source>Images smaller than window will be zoomed in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2323"/>
        <source>Zoom options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2330"/>
        <source>Unlock minimum zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2340"/>
        <source>Always allow zooming below 100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2365"/>
        <source>Zoom step:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2433"/>
        <source>[step]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2462"/>
        <source>Use fixed zoom levels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2506"/>
        <source>Load defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2574"/>
        <source>Scaling quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2601"/>
        <source>Scaling filter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2633"/>
        <source>Nearest neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2638"/>
        <source>Bilinear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2680"/>
        <source>When unchecked, nearest neighbor algorithm will be used for upscaling.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2683"/>
        <source>Smooth upscaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2702"/>
        <source>Smooth animated images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2781"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2840"/>
        <source>Load preset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2853"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2857"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2862"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2867"/>
        <source>Dark Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2872"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2896"/>
        <source>Use system colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="2906"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;modify&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3132"/>
        <source>Accent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3139"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3146"/>
        <source>Background (fullscreen mode)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3184"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3191"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3291"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="62"/>
        <source>Overlay background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3329"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="60"/>
        <source>Widget background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3336"/>
        <source>Folder view top panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3343"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="61"/>
        <source>Widget border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3412"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="63"/>
        <source>Overlay text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3450"/>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="64"/>
        <source>Scrollbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3457"/>
        <source>Folder view background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3528"/>
        <source>Other window tweaks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3543"/>
        <source>Window opacity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3596"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3621"/>
        <source>Background blur (KDE)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3673"/>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3734"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4073"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3741"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4080"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3754"/>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4087"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3783"/>
        <source>Reset to defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3817"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3822"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3874"/>
        <source>Mouse &amp; touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3895"/>
        <source>Scroll image with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3903"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3908"/>
        <source>Touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3913"/>
        <source>Touchpad &amp; Mouse Wheel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3939"/>
        <source>Note: you can also zoom by holding RMB and moving the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3953"/>
        <source>Trackpad detection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3963"/>
        <source>Disable if you have issues with mouse scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="3995"/>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4051"/>
        <source>Note: these will appear in &quot;Open with&quot; menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4061"/>
        <source>Also, you can assign shortcuts to scripts (in &quot;Controls&quot; section).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4170"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4227"/>
        <source>Preload the next/previous image. Results in a much faster image switching (at the expense of wasting more RAM).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4230"/>
        <source>Use preloader (recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4240"/>
        <source>Load adjacent images in background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4268"/>
        <source>Thumbnailer thread count:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4306"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4337"/>
        <source>Use thumbnail cache (recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4344"/>
        <source>Unload off-screen thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4354"/>
        <source>Dynamically unload items to save memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4368"/>
        <source>Show save overlay when editing images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4383"/>
        <source>JPEG save quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4427"/>
        <source>q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4456"/>
        <source>Confirm moving to trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4468"/>
        <source>Confirm file delete (!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4482"/>
        <source>JXL animation support (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4510"/>
        <source>Memory allocation limit per image, MB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4571"/>
        <source>Mpv binary:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4612"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4706"/>
        <source>About qimgv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4757"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;This is a fast and easy to use image viewer&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Features video support via libmpv&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic;&quot;&gt;Github page:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic;&quot;&gt; &lt;/span&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;https://github.com/easymodo/qimgv&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic;&quot;&gt;Main developer:&lt;/span&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-style:italic;&quot;&gt; easymodo (easymodofrf@gmail.com)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv/graphs/contributors&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;Contributors&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;OpenCV enabled builds use &lt;/span&gt;&lt;a href=&quot;https://github.com/dbzhang800/QtOpenCV&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;QtOpenCV&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt; by dbzhang800&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:600; font-style:italic; text-decoration: underline; color:#007af4;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;qimgv is licensed under &lt;/span&gt;&lt;a href=&quot;https://www.gnu.org/licenses/gpl-3.0.en.html&quot;&gt;&lt;span style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;GNU GPL Version 3&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt;&quot;&gt;Report any issues / request features &lt;/span&gt;&lt;a href=&quot;https://github.com/easymodo/qimgv/issues&quot;&gt;&lt;span style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; text-decoration: underline; color:#007af4;&quot;&gt;here&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4850"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4857"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.ui" line="4864"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="9"/>
        <source>Preferences — </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="54"/>
        <source>Accent color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="55"/>
        <source>Windowed mode background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="56"/>
        <source>Fullscreen mode background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="57"/>
        <source>FolderView background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="58"/>
        <source>FolderView top panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="59"/>
        <source>Text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="569"/>
        <source>Edit shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/settingsdialog.cpp" line="620"/>
        <source>Navigate to mpv binary</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutCreatorDialog</name>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="14"/>
        <source>New shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="34"/>
        <source>Action:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="73"/>
        <source>Script:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="117"/>
        <source>Shortcut:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gui/dialogs/shortcutcreatordialog.ui" line="124"/>
        <source>[Enter shortcut]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../main.cpp" line="133"/>
        <source>File or directory path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="136"/>
        <source>Generate all thumbnails for directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="137"/>
        <source>directory-path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="139"/>
        <source>Thumbnail size. Current size is used if not specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="140"/>
        <source>thumbnail-size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="142"/>
        <source>Show build options.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
