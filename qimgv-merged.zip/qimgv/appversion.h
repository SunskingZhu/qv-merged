#pragma once

#include <QVersionNumber>

extern QVersionNumber appVersion;
